package bitcamp;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("bitcamp")
public class AppConfig {

}
